﻿/* /*
Copyright (c) 2014 David Stier

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


******Jello Physics was born out of Walabers JellyPhysics. As such, the JellyPhysics license has been include.
******The original JellyPhysics library may be downloaded at http://walaber.com/wordpress/?p=85.


Copyright (c) 2007 Walaber

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;

[CanEditMultipleObjects]
[CustomEditor(typeof(tk2dMeshLink))]
public class tk2dMeshLinkEditor : MeshLinkEditor 
{
	GUIContent updateMeshContent = new GUIContent("Update Mesh", "Make the mesh conform to the collider");


	protected override void Enabled ()
	{
		base.Enabled ();

	}

	protected override void DrawInspectorGUI ()
	{
		base.DrawInspectorGUI();

		serializedObject.Update();

		for(int i = 0; i < targets.Length; i++)
		{
			tk2dMeshLink link = (tk2dMeshLink)targets[i];
			link.sprite = link.GetComponent<tk2dSprite>();
		}
		
		DrawOffsetScaleAngleEditorGUI();
		
		if(GUILayout.Button(updateMeshContent, EditorStyles.miniButton))
		{
//			Undo.RecordObjects(serializedObject.targetObjects, "tk2dMeshLinkInspector");

			for(int i = 0; i < serializedObject.targetObjects.Length; i++)
			{
				tk2dMeshLink link = (tk2dMeshLink)serializedObject.targetObjects[i];

//				Undo.RecordObject(link, "tk2dMeshLinkInspector");
//				Undo.RecordObject(link.LinkedMeshFilter.sharedMesh, "tk2dMeshLinkInspector");
//				Undo.RecordObject(link.body, "tk2dMeshLinkInspector");
				
				link.Initialize(true);
				
//				EditorUtility.SetDirty(link);
//				EditorUtility.SetDirty(link.LinkedMeshFilter);
//				EditorUtility.SetDirty(link.body);
			}
		}

		serializedObject.ApplyModifiedProperties();
	}

	protected override void HandleScaleChanged ()
	{
		base.HandleScaleChanged ();

		for(int i = 0; i < serializedObject.targetObjects.Length; i++)
		{
			tk2dMeshLink link = (tk2dMeshLink)serializedObject.targetObjects[i];

			//Use reflection to modify the sprite scale in order to bypass the setter.
			FieldInfo fi = typeof(tk2dSprite).GetField("_scale", BindingFlags.NonPublic | BindingFlags.Instance);
			fi.SetValue (link.sprite, new Vector3(eScale.vector2Value.x, eScale.vector2Value.y, link.sprite.scale.z));

			EditorUtility.SetDirty(link.sprite);
		}
	}
}
