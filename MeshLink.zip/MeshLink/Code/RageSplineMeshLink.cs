/* /*
Copyright (c) 2014 David Stier

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


******Jello Physics was born out of Walabers JellyPhysics. As such, the JellyPhysics license has been include.
******The original JellyPhysics library may be downloaded at http://walaber.com/wordpress/?p=85.


Copyright (c) 2007 Walaber

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

using UnityEngine;
using System.Collections;
using System;

/// <summary>
/// The RageSplineMeshLink links the Mesh objects created via RageSpline to JelloBody objects for Mesh deformation.
/// </summary>
[RequireComponent (typeof (RageSpline))]
public class RageSplineMeshLink : MeshLink 
{
	/// <summary>
	/// The linked RageSpline.
	/// </summary>
	public RageSpline spline;

	/// <summary>
	/// The normals for each vertex of the spline.
	/// </summary>
	protected Vector2[] normals = new Vector2[0];

	protected float[] normalAngleOffsets = new float[0];

	protected float[] normalAngleScalars = new float[0];

	void Start()
	{
		//do this here so it overrides RageSplineMeshLink.
		Initialize(true);//reallly only the ragespline mesh link would need this if precaching were worked out.
	}

	/// <summary>
	/// Initialize the MeshLink.
	/// </summary>
	/// <param name="forceUpdate">Whether to force an update to the MeshLink and MeshLink.LinkedMeshFilter.sharedMesh.</param>
	public override void Initialize (bool forceUpdate = false)
	{
		base.Initialize ();

		meshLinkType = MeshLink.MeshLinkType.RageSplineMeshLink;

		spline = GetComponent<RageSpline>();

		spline.LockPhysicsToAppearence = true;
		spline.SetPhysics(RageSpline.Physics.Polygon);
		spline.SetCreatePhysicsInEditor(true);
		spline.PhysicsIsTrigger = true;
		spline.AutoRefresh = false;

		if(forceUpdate || LinkedMeshFilter.sharedMesh == null)
		{
			spline.RefreshMesh (); //rebuild the spline according to RageSpline and then replace the fill with my own fill (only if there are internal points?)

			Vector2[] fill = GetVerticesAndUpdateCollider();
			bool multipleMaterials = spline.Mrenderer.sharedMaterials.GetLength(0) > 1;


			Color[] colors;
			Vector2[] uv1;
			Vector2[] uv2;
			int[] newTris1;
			int[] newTris2 = LinkedMeshFilter.sharedMesh.GetTriangles(1);


			if(spline.fill == RageSpline.Fill.Landscape)
			{
				int vertexCount = LinkedMeshFilter.sharedMesh.colors.Length + body.Shape.InternalVertexCount - (body.Shape.EdgeVertexCount - 4);

				colors = new Color[vertexCount];
				uv1 = new Vector2[vertexCount];
				uv2 = new Vector2[vertexCount];
				vertices = new Vector3[vertexCount];


				for(int i = 0; i < body.Shape.EdgeVertexCount; i++)
				{
					//edge points
					if(i == 0)//landscape lower left point....
					{
						vertices[i] = (Vector3)fill[i];
						colors[i] = LinkedMeshFilter.sharedMesh.colors[i];
						uv1[i] = LinkedMeshFilter.sharedMesh.uv[i];
						uv2[i] = LinkedMeshFilter.sharedMesh.uv2[i];
					}
					else if(i < body.Shape.EdgeVertexCount - 1) //top spline points...
					{
						vertices[i] = (Vector3)fill[i];
						colors[i] = LinkedMeshFilter.sharedMesh.colors[body.Shape.EdgeVertices.Length - 3 + i];
						uv1[i] = LinkedMeshFilter.sharedMesh.uv[body.Shape.EdgeVertices.Length - 3 + i];
						uv2[i] = LinkedMeshFilter.sharedMesh.uv2[body.Shape.EdgeVertices.Length - 3 + i];
					}
					else if(i == body.Shape.EdgeVertexCount - 1)//landscape lower right point...
					{
						vertices[i] = (Vector3)fill[i];
						colors[i] = LinkedMeshFilter.sharedMesh.colors[body.Shape.EdgeVertexCount - 3];
						uv1[i] = LinkedMeshFilter.sharedMesh.uv[body.Shape.EdgeVertexCount - 3];
						uv2[i] = LinkedMeshFilter.sharedMesh.uv2[body.Shape.EdgeVertexCount - 3];
					}
				}

				if(body.Shape.InternalVertexCount > 0) //TODO handle internal points within the AA area????
				{
					//i need the triangulation of the base shape without any internal points......
					for(int i = body.Shape.EdgeVertexCount; i < body.Shape.VertexCount; i++)
					{
						vertices[i] = body.Shape.getVertex(i);
						int containingSegment = -1;
						//i can find the containing band via projection onto the spline line segments....
						for(int a = 0; a < (body.Shape.EdgeVertexCount - 2 ) * 2 - 1; a++)
						{

							if(vertices[i].x >= LinkedMeshFilter.sharedMesh.vertices[a].x && vertices[i].x <= LinkedMeshFilter.sharedMesh.vertices[a + 1].x)
							{
								containingSegment = a;
								break;
							}
						}

						if(containingSegment == -1)
							Debug.LogError("Internal Point Masses must lie within the ragespline fill");

						float[] barycentriccorrds;
						int[] triangleIndices = new int[3];
						Vector2[] triangleVertices = new Vector2[3];
						if(JelloVectorTools.CrossProduct(vertices[i] - LinkedMeshFilter.sharedMesh.vertices[containingSegment], LinkedMeshFilter.sharedMesh.vertices[containingSegment + (body.Shape.EdgeVertexCount - 2 ) + 1] - LinkedMeshFilter.sharedMesh.vertices[containingSegment]) < 0f)// which is on the right side???
						{
							//this is the left side
							triangleIndices[0] = containingSegment + body.Shape.EdgeVertexCount - 2;
							triangleIndices[1] = containingSegment + body.Shape.EdgeVertexCount - 1;
							triangleIndices[2] = containingSegment;
						}
						else
						{
							//this is the right side
							triangleIndices[0] = containingSegment + body.Shape.EdgeVertexCount - 1; //TODO i can just use dist between top and bottom becaue it will always be the same!!!!
							triangleIndices[2] = containingSegment;
							triangleIndices[1] = containingSegment + 1;
						}

						triangleVertices[0] = LinkedMeshFilter.sharedMesh.vertices[triangleIndices[0]];
						triangleVertices[1] = LinkedMeshFilter.sharedMesh.vertices[triangleIndices[1]];
						triangleVertices[2] = LinkedMeshFilter.sharedMesh.vertices[triangleIndices[2]];

						barycentriccorrds = JelloShapeTools.GetBarycentricCoords (vertices[i], triangleVertices);

						colors[i] = LinkedMeshFilter.sharedMesh.colors[triangleIndices[0]] * barycentriccorrds[0] + LinkedMeshFilter.sharedMesh.colors[triangleIndices[1]] * barycentriccorrds[1] + LinkedMeshFilter.sharedMesh.colors[triangleIndices[2]] * barycentriccorrds[2]; 
						if(spline.GetTexturing1() == RageSpline.UVMapping.Fill || spline.GetTexturing2() == RageSpline.UVMapping.Fill)
						{
							uv1[i] = spline.GetFillUV(vertices[i]);
							uv2[i] = spline.GetFillUV2(vertices[i]);
						}
						else
						{
							uv1[i] = uv1[0];
							uv2[i] = uv2[0];
						}
					}
				}

				//the rest of the points. (AA and Outline) //need to modify AA and maybe outline verts...
				for(int i = 0; i < LinkedMeshFilter.sharedMesh.vertices.Length - (body.Shape.EdgeVertexCount - 2) * 2; i++)
				{
					//may have to treat outline and AA differently... //i have to find the verts myself? because ragespline is fucked up by itself????

					vertices[body.Shape.VertexCount + i] = LinkedMeshFilter.sharedMesh.vertices[(body.Shape.EdgeVertexCount - 2) * 2 + i];
					colors[body.Shape.VertexCount + i] = LinkedMeshFilter.sharedMesh.colors[(body.Shape.EdgeVertexCount - 2) * 2 + i];
					uv1[body.Shape.VertexCount + i] = LinkedMeshFilter.sharedMesh.uv[(body.Shape.EdgeVertexCount - 2) * 2 + i];
					uv2[body.Shape.VertexCount + i] = LinkedMeshFilter.sharedMesh.uv2[(body.Shape.EdgeVertexCount - 2) * 2 + i];
				}
				
				bool fillAntialiasing = false;
				float aaWidth = spline.GetAntialiasingWidth();
				if (aaWidth > 0f)
				{
					if (spline.inverseTriangleDrawOrder)
						fillAntialiasing = true;
					else if (spline.GetOutline() == RageSpline.Outline.None || 
					         Mathf.Abs(spline.GetOutlineNormalOffset()) > (spline.GetOutlineWidth()+(aaWidth)))
						fillAntialiasing = true;
				}

				RageSpline.RageVertex[] fillVerts = spline.GenerateFillVerts(fillAntialiasing, multipleMaterials);
				int numFillTris = spline.GetFillTriangleCount(fillVerts, fillAntialiasing);
				int numAAFillTris = fillAntialiasing ? (body.Shape.EdgeVertexCount - 2) * 2 : 0;

				int[] newFillTris = body.Shape.Triangles;
				int[] subtris1 = LinkedMeshFilter.sharedMesh.GetTriangles(0);

				newTris1 = new int[subtris1.Length - (numFillTris - numAAFillTris) * 3 + newFillTris.Length];

				int v = 0;
				for(int i = 0; i < newFillTris.Length; i++)
				{
					newTris1[i] = newFillTris[i];
					v++;
				}
				if(fillAntialiasing)//handle fill antialiasing //TODO move all not fill into a single loop and assign triangles in bands...
				{
					for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
					{
						newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * 2 - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
						newTris1[v++] = 2 + i;
						newTris1[v++] = 1 + i;
						newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * 2 - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
						newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * 2 - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
						newTris1[v++] = 2 + i;
					}
				}
				if(multipleMaterials)
				{
					v = 0;
					//handle outline if present.
					if(spline.outline != RageSpline.Outline.None)
					{
						int offset;
						if(spline.antiAliasingWidth > 0)
						{
							offset = fillAntialiasing ? 3 : 2;
							//handle outline inside antialiasing 
							for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
							{
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
							}
							
							//handle outline
							offset ++;
							for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
							{
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
							}

							//fix the outline band that is currently screwed up in Ragesplines own code.....
							for(int i = 0; i < body.Shape.EdgeVertexCount - 2; i++)
								vertices[(body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i] = vertices[(body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i] + (vertices[(body.Shape.EdgeVertexCount - 2) * (offset + 2) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i] - vertices[(body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i]).normalized * spline.GetOutlineWidth(i);
							
							//handle outline outside antialiasing
							offset++;
							for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
							{
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
							}
						}
						else
						{
							//handle outline
							offset = fillAntialiasing ? 3 : 2;
							for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
							{
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris2[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
							}
						}
					}
				}
				else
				{
					//handle outline if present.
					if(spline.outline != RageSpline.Outline.None)
					{
						int offset;
						if(spline.antiAliasingWidth > 0)
						{
							offset = fillAntialiasing ? 3 : 2;
							//handle outline inside antialiasing 
							for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
							{
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
							}
							
							//handle outline
							offset ++;
							for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
							{
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
							}

							//fix the ouline verts screwed up by rageplines own code...
							for(int i = 0; i < body.Shape.EdgeVertexCount - 2; i++)
								vertices[(body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i] = vertices[(body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i] + (vertices[(body.Shape.EdgeVertexCount - 2) * (offset + 2) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i] - vertices[(body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i]).normalized * spline.GetOutlineWidth(i);

							//handle outline outside antialiasing
							offset++;
							for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
							{
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
							}
							
						}
						else
						{
							//handle outline
							offset = fillAntialiasing ? 3 : 2;
							for(int i = 0; i < body.Shape.EdgeVertexCount - 3; i++)//fill AA triangles
							{
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * offset - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
								newTris1[v++] = (body.Shape.EdgeVertexCount - 2) * (offset + 1) - (body.Shape.EdgeVertexCount - 4) + body.Shape.InternalVertexCount + i + 1;
							}
						}
					}
				}
			}
			else
			{

				if(body.Shape.InternalVertexCount <= 0) //TODO come back to this...
				{
					vertices = new Vector3[LinkedMeshFilter.sharedMesh.vertices.Length];
					return;
				}

				int vertexCount = LinkedMeshFilter.sharedMesh.vertices.Length + body.Shape.InternalVertexCount;

				colors = new Color[vertexCount];
				uv1 = new Vector2[vertexCount];
				uv2 = new Vector2[vertexCount];
				vertices = new Vector3[vertexCount];

				for(int i = 0; i < body.Shape.VertexCount; i++)
				{
					//edge points
					if(i < body.Shape.EdgeVertexCount)
					{
						vertices[i] = (Vector3)fill[i];
						colors[i] = LinkedMeshFilter.sharedMesh.colors[i];
						uv1[i] = LinkedMeshFilter.sharedMesh.uv[i];
						uv2[i] = LinkedMeshFilter.sharedMesh.uv2[i];
					}
					else//internal points
					{
						vertices[i] = (Vector3)body.Shape.getVertex(i);
						colors[i] = spline.GetFillColor(vertices[i]);
						uv1[i] = spline.GetFillUV(vertices[i]);
						uv2[i] = spline.GetFillUV2(vertices[i]);
					}
				}
				//the rest of the points. Fill AA, Outline, and Outline AA)
				for(int i = 0; i < LinkedMeshFilter.sharedMesh.vertices.Length - body.Shape.EdgeVertexCount; i++)
				{
					vertices[body.Shape.VertexCount + i] = LinkedMeshFilter.sharedMesh.vertices[body.Shape.EdgeVertexCount + i];
					colors[body.Shape.VertexCount + i] = LinkedMeshFilter.sharedMesh.colors[body.Shape.EdgeVertexCount + i];
					uv1[body.Shape.VertexCount + i] = LinkedMeshFilter.sharedMesh.uv[body.Shape.EdgeVertexCount + i];
					uv2[body.Shape.VertexCount + i] = LinkedMeshFilter.sharedMesh.uv2[body.Shape.EdgeVertexCount + i];
				}



				bool fillAntialiasing = false;
				float aaWidth = spline.GetAntialiasingWidth();
				if (aaWidth > 0f)
				{
					if (spline.inverseTriangleDrawOrder)
						fillAntialiasing = true;
					else if (spline.GetOutline() == RageSpline.Outline.None || 
					         Mathf.Abs(spline.GetOutlineNormalOffset()) > (spline.GetOutlineWidth()+(aaWidth)))
						fillAntialiasing = true;
				}


				int offset = fillAntialiasing ? 2 : 1;
				//fix the ouline verts screwed up by rageplines own code...
				if(spline.GetOutlineNormalOffset() > 0 && aaWidth > 0f)
					for(int i = 0; i < body.Shape.EdgeVertexCount + 1; i++)
						vertices[body.Shape.EdgeVertexCount * offset + (body.Shape.EdgeVertexCount + 1) * 2 + body.Shape.InternalVertexCount + i] = vertices[body.Shape.EdgeVertexCount * offset + (body.Shape.EdgeVertexCount + 1) * 1 + body.Shape.InternalVertexCount + i] - (vertices[body.Shape.EdgeVertexCount * offset + (body.Shape.EdgeVertexCount + 1) * 3 + body.Shape.InternalVertexCount + i] - vertices[body.Shape.EdgeVertexCount * offset + (body.Shape.EdgeVertexCount + 1) * 2 + body.Shape.InternalVertexCount + i]).normalized * spline.GetOutlineWidth(i);

				if(multipleMaterials && body.Shape.InternalVertexCount > 0)
					for(int i = 0; i < newTris2.Length; i++)
						newTris2[i] += body.Shape.InternalVertexCount;

				RageSpline.RageVertex[] fillVerts = spline.GenerateFillVerts(fillAntialiasing, multipleMaterials);
				int numFillTris = spline.GetFillTriangleCount(fillVerts, fillAntialiasing);
				int numAAFillTris = fillAntialiasing ? body.Shape.EdgeVertexCount * 2 : 0;
				
				int[] newFillTris = body.Shape.Triangles;
				int[] subtris1 = LinkedMeshFilter.sharedMesh.GetTriangles(0);
				newTris1 = new int[subtris1.Length - (numFillTris - numAAFillTris) * 3 + newFillTris.Length];

				int v = 0;

				for(int i = 0; i < newFillTris.Length; i++)
					newTris1[v++] = newFillTris[i];
				
				for(int i = (numFillTris - numAAFillTris) * 3; i < subtris1.Length; i++)
				{
					newTris1[v] = subtris1[i];
					
					if(newTris1[v] >= body.Shape.EdgeVertexCount)
					{
						newTris1[v] += body.Shape.InternalVertexCount;
					}

					v++;
				}
			}

			LinkedMeshFilter.sharedMesh.Clear ();
			LinkedMeshFilter.sharedMesh.subMeshCount = 2;
			LinkedMeshFilter.sharedMesh.vertices = vertices;
			LinkedMeshFilter.sharedMesh.colors = colors;
			LinkedMeshFilter.sharedMesh.uv = uv1;
			LinkedMeshFilter.sharedMesh.uv2 = uv2;
			LinkedMeshFilter.sharedMesh.SetTriangles(newTris1, 0);
			LinkedMeshFilter.sharedMesh.SetTriangles(newTris2, 1);
			LinkedMeshFilter.sharedMesh.RecalculateNormals();
			calculateMeshTangents();//mesh);
			
			LinkedMeshFilter.sharedMesh.RecalculateBounds();
			LinkedMeshFilter.sharedMesh.Optimize();
			LinkedMeshFilter.sharedMesh.MarkDynamic();
		}
	}


	/// <summary>
	/// Get the vertices of RageSplineMeshLink.spline.
	/// </summary>
	/// <returns>The vertices.</returns>
	public Vector2[] GetVerticesAndUpdateCollider ()
	{

		Vector2[] returnVertices = new Vector2[0];
		RageSpline.RageVertex[] splits2;
	
		if(spline.fill != RageSpline.Fill.Landscape)
		{
			splits2 = spline.GetSplits(spline.GetVertexCount(), 0f, 1f);


			returnVertices = new Vector2[splits2.Length - 1];
			for (int i = 0; i < splits2.Length - 1; i++) //dont get the very last one, it is a duplicate of the first.
			{
				returnVertices[i] = body.polyCollider.points[i];//splits2[i].position;
//				float width = spline.corners ==  RageSpline.Corner.Beak ? (spline.FindNormal(splits2[i - 1 >= 0 ? i - 1 : splits2.Length - 2].position, splits2[i].position, splits2[i + 1 < splits2.Length - 1 ? i + 1 : 0].position, spline.OutlineWidth)).magnitude : spline.OutlineWidth;
//				if(spline.corners == RageSpline.Corner.Beak)
//					if(width > spline.maxBeakLength * spline.OutlineWidth)
//						width = spline.maxBeakLength * spline.OutlineWidth; //TODO finish working with beak...
			}

			if(normals.Length != returnVertices.Length)
				normals = new Vector2[returnVertices.Length];

			if(normalAngleScalars.Length != returnVertices.Length)
				normalAngleScalars = new float[returnVertices.Length];

			for(int i = 0; i < returnVertices.Length; i++)
			{
				normals[i] = spline.GetNormal(splits2[i].splinePosition);

				int prev = i - 1 >= 0 ? i - 1 : returnVertices.Length - 1;
				int next = i + 1 < returnVertices.Length ? i + 1 : 0;

				float dot = Vector2.Dot((returnVertices[prev] - returnVertices[i]).normalized, normals[i]);
				if (dot > 1.0f) { dot = 1.0f; }
				if (dot < -1.0f) { dot = -1.0f; }
				float thisAngle = Mathf.Acos(dot);
				if (JelloVectorTools.isCCW(returnVertices[prev] - returnVertices[i], normals[i])) { thisAngle = -thisAngle; }
				if(thisAngle < 0)
					thisAngle += Mathf.PI + Mathf.PI;

				dot = Vector2.Dot((returnVertices[prev] - returnVertices[i]).normalized, (returnVertices[next] - returnVertices[i]).normalized);
				if (dot > 1.0f) { dot = 1.0f; }
				if (dot < -1.0f) { dot = -1.0f; }
				float totalAngle = Mathf.Acos(dot);
				if (JelloVectorTools.isCCW(returnVertices[prev] - returnVertices[i], returnVertices[next] - returnVertices[i])) { totalAngle = -totalAngle; }
				if(totalAngle < 0)
					totalAngle += Mathf.PI + Mathf.PI;

				normalAngleScalars[i] = totalAngle != 0f ? thisAngle / totalAngle : 0f;
			}
		} 
		else 
		{
			splits2 = spline.GetSplits(spline.GetVertexCount(), 0f, 1f);

			returnVertices = new Vector2[splits2.Length + 2];

			if(normals.Length != returnVertices.Length - 2)
				normals = new Vector2[returnVertices.Length - 2];

			if(normalAngleScalars.Length != returnVertices.Length - 2)
				normalAngleScalars = new float[returnVertices.Length - 2];

			returnVertices[0] = body.polyCollider.points[0];
			for(int i = 1; i < returnVertices.Length - 1; i++)
			{
				normals[i - 1] = spline.GetNormal(splits2[i - 1].splinePosition);
				int prev = i - 1;
				int next = i + 1;

				Vector2 edgeNorm = (body.polyCollider.points[prev] - body.polyCollider.points[i]).normalized;

				float dot = Vector2.Dot(edgeNorm, normals[i - 1]);
				if (dot > 1.0f) { dot = 1.0f; }
				if (dot < -1.0f) { dot = -1.0f; }
				float thisAngle = Mathf.Acos(dot);
				if (JelloVectorTools.isCCW(edgeNorm, normals[i - 1])) { thisAngle = -thisAngle; }
				if(thisAngle < 0)
					thisAngle += Mathf.PI + Mathf.PI;
				
				dot = Vector2.Dot(edgeNorm, (body.polyCollider.points[next] - body.polyCollider.points[i]).normalized);
				if (dot > 1.0f) { dot = 1.0f; }
				if (dot < -1.0f) { dot = -1.0f; }
				float totalAngle = Mathf.Acos(dot);
				if (JelloVectorTools.isCCW(edgeNorm, body.polyCollider.points[next] - body.polyCollider.points[i])) { totalAngle = -totalAngle; }
				if(totalAngle < 0)
					totalAngle += Mathf.PI + Mathf.PI;

				normalAngleScalars[i - 1] = totalAngle != 0f ? thisAngle / totalAngle : 0f;
				returnVertices[i] = body.polyCollider.points[i] - normals[i - 1] * spline.GetPhysicsNormalOffset();
			}
			returnVertices[returnVertices.Length - 1] = body.polyCollider.points[returnVertices.Length - 1];
		}

		return returnVertices;
	}

	/// <summary>
	/// Update the pivot point.
	/// </summary>
	/// <param name="change">The amount by which to change the pivot point.</param>
	/// <param name="monoBehavior">The MonoBehavior that may have been affected by change in pivot point. This is used mainly for setting it dirty in the Editor.</param>
	/// <returns>Whether the pivot point was updated.</returns>
	public override bool UpdatePivotPoint (Vector2 change, out MonoBehaviour monoBehavior)
	{

		for(int i = 0; i < spline.GetPointCount(); i++)
			spline.SetPoint(i, spline.GetPosition(i) - (Vector3)change);
	
		spline.RefreshMesh();

		//monoBehavior = spline;
		monoBehavior = GetComponent<RageSplineMeshLink>();

		return true;
	}


	/// <summary>
	/// Update the MeshLink.LinkedMeshFilter.sharedMesh.vertices.
	/// This is called each Update() and drives the continuous MeshLink.LinkedMeshFilter.sharedMesh deformation.
	/// </summary>
	/// <param name="points">The basis of the new MeshLink.LinkedMeshFilter.sharedMesh.vertices.</param>
	public override void UpdateMesh (Vector2[] points) //TODO account for internal point masses...
	{	
		if(spline.fill == RageSpline.Fill.Landscape)
		{	
			if(vertices.Length != LinkedMeshFilter.sharedMesh.vertices.Length)
				Initialize(true);
			
			int v = 0;
			
			bool fillAntialiasing = false;
			float aaWidth = spline.GetAntialiasingWidth();
			if (aaWidth > 0f)
			{
				if (spline.inverseTriangleDrawOrder)
					fillAntialiasing = true;
				else if (spline.GetOutline() == RageSpline.Outline.None || 
				         Mathf.Abs(spline.GetOutlineNormalOffset()) > (spline.GetOutlineWidth()+(aaWidth)))
					fillAntialiasing = true;
			}

			for(int i = 0; i < points.Length; i++)
			{
				if(i > 0 && i < body.EdgePointMassCount - 1)
				{
					int prev = i - 1;
					int next = i + 1;

					Vector2 edgeNorm = (points[prev] - points[i]).normalized;

					float dot = Vector2.Dot(edgeNorm, (points[next] - points[i]).normalized);
					if (dot > 1.0f) { dot = 1.0f; }
					if (dot < -1.0f) { dot = -1.0f; }
					float totalAngle = Mathf.Acos(dot);
					if (JelloVectorTools.isCCW(edgeNorm, points[next] - points[i])) { totalAngle = -totalAngle; }
					if(totalAngle < 0)
						totalAngle += Mathf.PI + Mathf.PI;

					normals[i - 1] = (Vector3)JelloVectorTools.rotateVector(edgeNorm, -totalAngle * Mathf.Rad2Deg * normalAngleScalars[i - 1]);

					vertices[i] = (Vector3)(points[i] - normals[i - 1] * spline.GetPhysicsNormalOffset());
				}
				else
				{
					vertices[i] = (Vector3)points[i];
				}
				
				v++;
			}

			//put all fill antialiasing vertices into place
			if(fillAntialiasing)
				for(int i = 0; i < body.EdgePointMassCount - 2; i++)
					vertices[v++] = vertices[i + 1] + (Vector3)normals[i] * spline.antiAliasingWidth;

			if(spline.emboss != RageSpline.Emboss.None)
				Debug.LogError("Emboss not currently supported");

			//put outline vertices into place.
			if(spline.outline == RageSpline.Outline.Loop)
			{
				if(spline.antiAliasingWidth > 0f)
				{
					//outline with antialiasing

					//outter ring antialiasing
					for(int i = 0; i < body.EdgePointMassCount - 2; i++)	
						vertices[v++] = vertices[i + 1] + (Vector3)normals[i] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f + spline.antiAliasingWidth);

					//outter ring
					for(int i = 0; i < body.EdgePointMassCount - 2; i++)
						vertices[v++] = vertices[i + 1] + (Vector3)normals[i] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f);

					//inner ring
					for(int i = 0; i < body.EdgePointMassCount - 2; i++)
						vertices[v++] = vertices[i + 1] + (Vector3)normals[i] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f);

					//inner ring antialiasing
					for(int i = 0; i < body.EdgePointMassCount - 2; i++)
						vertices[v++] = vertices[i + 1] + (Vector3)normals[i] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f - spline.antiAliasingWidth);//outline antialiasing

				} 
				else 
				{
					//outline without antialiasing
					 
					//outter ring
					for(int i = 0; i < body.EdgePointMassCount - 2; i++)
						vertices[v++] = vertices[i + 1] + (Vector3)normals[i] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f);

					//inner ring
					for(int i = 0; i < body.EdgePointMassCount - 2; i++)
						vertices[v++] = vertices[i + 1] + (Vector3)normals[i] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f);//outline
				}
			}
			else if(spline.outline == RageSpline.Outline.Free)
			{
				Debug.LogWarning("Free outline not currently supported");
			}
		}
		else //Not landscape fill
		{	
			if(vertices.Length != LinkedMeshFilter.sharedMesh.vertices.Length)
				Initialize(true);
			
			int v = 0;
			
			bool fillAntialiasing = false;
			float aaWidth = spline.GetAntialiasingWidth();
			if (aaWidth > 0f)
			{
				if (spline.inverseTriangleDrawOrder)
					fillAntialiasing = true;
				else if (spline.GetOutline() == RageSpline.Outline.None || 
				         Mathf.Abs(spline.GetOutlineNormalOffset()) > (spline.GetOutlineWidth()+(aaWidth)))
					fillAntialiasing = true;
			}

			for(int i = 0; i < points.Length; i++)
			{
				if(i < body.EdgePointMassCount)
				{
					int prev = i - 1 >= 0 ? i - 1 : body.EdgePointMassCount - 1;
					int next = i + 1 < body.EdgePointMassCount ? i + 1 : 0;

					Vector2 edgeNorm = (points[prev] - points[i]).normalized;

					float dot = Vector2.Dot(edgeNorm, (points[next] - points[i]).normalized);
					if (dot > 1.0f) { dot = 1.0f; }
					if (dot < -1.0f) { dot = -1.0f; }
					float totalAngle = Mathf.Acos(dot);
					if (JelloVectorTools.isCCW(edgeNorm, points[next] - points[i])) { totalAngle = -totalAngle; }
					if(totalAngle < 0)
						totalAngle += Mathf.PI + Mathf.PI;

					normals[i] = (Vector3)JelloVectorTools.rotateVector(edgeNorm, -totalAngle * Mathf.Rad2Deg * normalAngleScalars[i]);
					vertices[i] = (Vector3)(points[i] - normals[i] * spline.GetPhysicsNormalOffset());
				}
				else
				{
					vertices[i] = (Vector3)points[i];
				}
				
				v++;
			}
			
			if(fillAntialiasing)
				for(int i = 0; i < body.EdgePointMassCount; i++)
					vertices[v++] = vertices[i] + (Vector3)normals[i] * spline.antiAliasingWidth;
					
			if(spline.emboss != RageSpline.Emboss.None)
				Debug.LogError("Emboss not currently supported");

			if(spline.outline == RageSpline.Outline.Loop)
			{
				if(spline.antiAliasingWidth > 0f)
				{
					for(int i = 0; i < body.EdgePointMassCount; i++)		//outter ring antialiasing
						vertices[v++] = vertices[i] + (Vector3)normals[i] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f + spline.antiAliasingWidth);//outline antialiasing
					vertices[v++] = vertices[0] + (Vector3)normals[0] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f + spline.antiAliasingWidth);//outline antialiasing

					for(int i = 0; i < body.EdgePointMassCount; i++)//outter ring
						vertices[v++] = vertices[i] + (Vector3)normals[i] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f);//outline
					vertices[v++] = vertices[0] + (Vector3)normals[0] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f);//outline

					
					for(int i = 0; i < body.EdgePointMassCount; i++)//inner ring
						vertices[v++] = vertices[i] + (Vector3)normals[i] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f);//outline
					vertices[v++] = vertices[0] + (Vector3)normals[0] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f);//outline	

					for(int i = 0; i < body.EdgePointMassCount; i++)//inner ring antialiasing
						vertices[v++] = vertices[i] + (Vector3)normals[i] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f - spline.antiAliasingWidth);//outline antialiasing
					vertices[v++] = vertices[0] + (Vector3)normals[0] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f - spline.antiAliasingWidth);//outline antialiasing
				} 
				else 
				{
					for(int i = 0; i < body.EdgePointMassCount; i++)//outter ring
						vertices[v++] = vertices[i] + (Vector3)normals[i] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f);//outline
					vertices[v++] = vertices[0] + (Vector3)normals[0] * (spline.outlineNormalOffset + spline.OutlineWidth * 0.5f);//outline

					for(int i = 0; i < body.EdgePointMassCount; i++)//inner ring
						vertices[v++] = vertices[i] + (Vector3)normals[i] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f);//outline
					vertices[v++] = vertices[0] + (Vector3)normals[0] * (spline.outlineNormalOffset - spline.OutlineWidth * 0.5f);//outline
				}
			}
			else if(spline.outline == RageSpline.Outline.Free)
			{
				Debug.LogWarning("Free outline not currently supported");
			}
		}	

		LinkedMeshFilter.sharedMesh.vertices = vertices;
		LinkedMeshFilter.sharedMesh.RecalculateBounds();
	}
		
}
